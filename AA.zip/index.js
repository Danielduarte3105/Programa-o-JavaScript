console.log("Média de notas");

console.log("Digite o nome do aluno: ");
let T1 = prompt("");

console.log("Digite a nota do primeiro bimestre de", T1);
let Texto1 = prompt("");
let n1 = Number(Texto1);

console.log("Digite a nota do segundo bimestre de", T1);
let Texto2 = prompt("");
let n2 = Number(Texto2);

console.log("Digite a nota do terceiro bimestre de", T1);
let Texto3 = prompt("");
let n3 = Number(Texto3);

console.log("Digite a nota do quarto bimestre de", T1);
let Texto4 = prompt("");
let n4 = Number(Texto4);

let Soma = n1+n2+n3+n4/5

if (Soma >= 6){
   console.log("O aluno", T1,"foi aprovado e sua média final foi", Soma)}
else console.log("Reprovado! A media final de", T1,"foi de ", Soma)
